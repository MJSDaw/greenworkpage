pg_dump: last built-in OID is 16383
pg_dump: reading extensions
pg_dump: identifying extension members
pg_dump: reading schemas
pg_dump: reading user-defined tables
pg_dump: reading user-defined functions
pg_dump: reading user-defined types
pg_dump: reading procedural languages
pg_dump: reading user-defined aggregate functions
pg_dump: reading user-defined operators
pg_dump: reading user-defined access methods
pg_dump: reading user-defined operator classes
pg_dump: reading user-defined operator families
pg_dump: reading user-defined text search parsers
pg_dump: reading user-defined text search templates
pg_dump: reading user-defined text search dictionaries
pg_dump: reading user-defined text search configurations
pg_dump: reading user-defined foreign-data wrappers
pg_dump: reading user-defined foreign servers
pg_dump: reading default privileges
pg_dump: reading user-defined collations
pg_dump: reading user-defined conversions
pg_dump: reading type casts
pg_dump: reading transforms
pg_dump: reading table inheritance information
pg_dump: reading event triggers
pg_dump: finding extension tables
pg_dump: finding inheritance relationships
pg_dump: reading column info for interesting tables
pg_dump: finding table default expressions
pg_dump: finding table check constraints
pg_dump: flagging inherited columns in subtables
pg_dump: reading partitioning data
pg_dump: reading indexes
pg_dump: flagging indexes in partitioned tables
pg_dump: reading extended statistics
pg_dump: reading constraints
pg_dump: reading triggers
pg_dump: reading rewrite rules
pg_dump: reading policies
pg_dump: reading row-level security policies
pg_dump: reading publications
pg_dump: reading publication membership of tables
pg_dump: reading publication membership of schemas
pg_dump: reading subscriptions
pg_dump: reading large objects
pg_dump: reading dependency data
pg_dump: saving encoding = UTF8
pg_dump: saving standard_conforming_strings = on
pg_dump: saving search_path = 
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-0+deb12u1)

-- Started on 2025-05-23 15:31:03 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

pg_dump: creating TABLE "public.admins"
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 226 (class 1259 OID 58697)
-- Name: admins; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.admins (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    image character varying(255),
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.admins OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.admins_id_seq"
--
-- TOC entry 225 (class 1259 OID 58696)
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.admins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admins_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.admins_id_seq"
--
-- TOC entry 3486 (class 0 OID 0)
-- Dependencies: 225
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


pg_dump: creating TABLE "public.audits"
--
-- TOC entry 230 (class 1259 OID 58717)
-- Name: audits; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.audits (
    id bigint NOT NULL,
    admin_id bigint NOT NULL,
    action character varying(255) NOT NULL,
    table_name character varying(255) NOT NULL,
    record_id bigint,
    old_values text,
    new_values text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.audits OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.audits_id_seq"
--
-- TOC entry 229 (class 1259 OID 58716)
-- Name: audits_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audits_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.audits_id_seq"
--
-- TOC entry 3487 (class 0 OID 0)
-- Dependencies: 229
-- Name: audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.audits_id_seq OWNED BY public.audits.id;


pg_dump: creating TABLE "public.bookings"
--
-- TOC entry 236 (class 1259 OID 58761)
-- Name: bookings; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.bookings (
    id bigint NOT NULL,
    space_id bigint NOT NULL,
    user_id bigint NOT NULL,
    start_time timestamp(0) without time zone NOT NULL,
    end_time timestamp(0) without time zone NOT NULL,
    status character varying(255) DEFAULT 'confirmed'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT bookings_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'confirmed'::character varying, 'cancelled'::character varying, 'completed'::character varying])::text[])))
);


ALTER TABLE public.bookings OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.bookings_id_seq"
--
-- TOC entry 235 (class 1259 OID 58760)
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.bookings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bookings_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.bookings_id_seq"
--
-- TOC entry 3488 (class 0 OID 0)
-- Dependencies: 235
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


pg_dump: creating TABLE "public.contacts"
--
-- TOC entry 228 (class 1259 OID 58708)
-- Name: contacts; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "termsAndConditions" boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.contacts OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.contacts_id_seq"
--
-- TOC entry 227 (class 1259 OID 58707)
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.contacts_id_seq"
--
-- TOC entry 3489 (class 0 OID 0)
-- Dependencies: 227
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


pg_dump: creating TABLE "public.failed_jobs"
--
-- TOC entry 220 (class 1259 OID 58664)
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.failed_jobs_id_seq"
--
-- TOC entry 219 (class 1259 OID 58663)
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.failed_jobs_id_seq"
--
-- TOC entry 3490 (class 0 OID 0)
-- Dependencies: 219
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


pg_dump: creating TABLE "public.migrations"
--
-- TOC entry 215 (class 1259 OID 58636)
-- Name: migrations; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.migrations_id_seq"
--
-- TOC entry 214 (class 1259 OID 58635)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.migrations_id_seq"
--
-- TOC entry 3491 (class 0 OID 0)
-- Dependencies: 214
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


pg_dump: creating TABLE "public.password_reset_tokens"
--
-- TOC entry 218 (class 1259 OID 58656)
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO "greenworkAdmin";

pg_dump: creating TABLE "public.payments"
--
-- TOC entry 232 (class 1259 OID 58731)
-- Name: payments; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    user_reservation_id bigint,
    space_reservation_id bigint,
    reservation_period character varying(255),
    amount numeric(10,2) NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    payment_method character varying(50),
    payment_date timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT payments_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'completed'::character varying])::text[])))
);


ALTER TABLE public.payments OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.payments_id_seq"
--
-- TOC entry 231 (class 1259 OID 58730)
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.payments_id_seq"
--
-- TOC entry 3492 (class 0 OID 0)
-- Dependencies: 231
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


pg_dump: creating TABLE "public.personal_access_tokens"
--
-- TOC entry 222 (class 1259 OID 58676)
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.personal_access_tokens_id_seq"
--
-- TOC entry 221 (class 1259 OID 58675)
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.personal_access_tokens_id_seq"
--
-- TOC entry 3493 (class 0 OID 0)
-- Dependencies: 221
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


pg_dump: creating TABLE "public.services"
--
-- TOC entry 234 (class 1259 OID 58750)
-- Name: services; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.services (
    id bigint NOT NULL,
    image_url character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    name character varying(255) NOT NULL
);


ALTER TABLE public.services OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.services_id_seq"
--
-- TOC entry 233 (class 1259 OID 58749)
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.services_id_seq"
--
-- TOC entry 3494 (class 0 OID 0)
-- Dependencies: 233
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


pg_dump: creating TABLE "public.spaces"
--
-- TOC entry 224 (class 1259 OID 58688)
-- Name: spaces; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.spaces (
    id bigint NOT NULL,
    places integer NOT NULL,
    price double precision NOT NULL,
    schedule character varying(255) NOT NULL,
    images character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    subtitle character varying(255) NOT NULL,
    address character varying(255),
    services character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.spaces OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.spaces_id_seq"
--
-- TOC entry 223 (class 1259 OID 58687)
-- Name: spaces_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.spaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spaces_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.spaces_id_seq"
--
-- TOC entry 3495 (class 0 OID 0)
-- Dependencies: 223
-- Name: spaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.spaces_id_seq OWNED BY public.spaces.id;


pg_dump: creating TABLE "public.users"
--
-- TOC entry 217 (class 1259 OID 58643)
-- Name: users; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    surname character varying(255) NOT NULL,
    dni character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    birthdate date NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    "termsAndConditions" boolean DEFAULT false NOT NULL,
    image character varying(255),
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.users_id_seq"
--
-- TOC entry 216 (class 1259 OID 58642)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.users_id_seq"
--
-- TOC entry 3496 (class 0 OID 0)
-- Dependencies: 216
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


pg_dump: creating DEFAULT "public.admins id"
--
-- TOC entry 3260 (class 2604 OID 58700)
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


pg_dump: creating DEFAULT "public.audits id"
--
-- TOC entry 3262 (class 2604 OID 58720)
-- Name: audits id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.audits ALTER COLUMN id SET DEFAULT nextval('public.audits_id_seq'::regclass);


pg_dump: creating DEFAULT "public.bookings id"
--
-- TOC entry 3266 (class 2604 OID 58764)
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


pg_dump: creating DEFAULT "public.contacts id"
--
-- TOC entry 3261 (class 2604 OID 58711)
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


pg_dump: creating DEFAULT "public.failed_jobs id"
--
-- TOC entry 3256 (class 2604 OID 58667)
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


pg_dump: creating DEFAULT "public.migrations id"
--
-- TOC entry 3253 (class 2604 OID 58639)
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


pg_dump: creating DEFAULT "public.payments id"
--
-- TOC entry 3263 (class 2604 OID 58734)
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


pg_dump: creating DEFAULT "public.personal_access_tokens id"
--
-- TOC entry 3258 (class 2604 OID 58679)
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


pg_dump: creating DEFAULT "public.services id"
--
-- TOC entry 3265 (class 2604 OID 58753)
-- Name: services id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


pg_dump: creating DEFAULT "public.spaces id"
--
-- TOC entry 3259 (class 2604 OID 58691)
-- Name: spaces id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.spaces ALTER COLUMN id SET DEFAULT nextval('public.spaces_id_seq'::regclass);


pg_dump: creating DEFAULT "public.users id"
--
-- TOC entry 3254 (class 2604 OID 58646)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3470 (class 0 OID 58697)
-- Dependencies: 226
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.admins"
COPY public.admins (id, name, email, password, email_verified_at, image, remember_token, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.admins"
1	admin	admin@greenwork.com	$2y$12$tHkzzv6fk9MmPuMX7B74Heo6mWxeWt3lSDfPUDNpffUwc6sTXPkr2	\N	\N	\N	\N	\N
\.


--
-- TOC entry 3474 (class 0 OID 58717)
-- Dependencies: 230
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.audits"
COPY public.audits (id, admin_id, action, table_name, record_id, old_values, new_values, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.audits"
1	1	delete	users	1	"{\\"id\\":1,\\"name\\":\\"Aileen\\",\\"surname\\":\\"Padr\\\\u00f3n Torres\\",\\"email\\":\\"aileenpadrontorres511@gmail.com\\",\\"birthdate\\":\\"2001-11-05T00:00:00.000000Z\\",\\"email_verified_at\\":null,\\"termsAndConditions\\":true,\\"image\\":null,\\"created_at\\":\\"2025-05-23T14:43:24.000000Z\\",\\"updated_at\\":\\"2025-05-23T14:43:24.000000Z\\"}"	\N	2025-05-23 16:03:08	2025-05-23 16:03:08
2	1	delete	users	2	"{\\"id\\":2,\\"name\\":\\"Aileen\\",\\"surname\\":\\"Padr\\\\u00f3n Torres\\",\\"email\\":\\"aileenpadrontorres511@gmail.com\\",\\"birthdate\\":\\"2001-11-05T00:00:00.000000Z\\",\\"email_verified_at\\":null,\\"termsAndConditions\\":true,\\"image\\":null,\\"created_at\\":\\"2025-05-23T15:04:29.000000Z\\",\\"updated_at\\":\\"2025-05-23T15:04:29.000000Z\\"}"	\N	2025-05-23 16:07:08	2025-05-23 16:07:08
3	1	update	users	3	"{\\"id\\":3,\\"name\\":\\"Aileen\\",\\"surname\\":\\"Padr\\\\u00f3n Torres\\",\\"email\\":\\"aileenpadrontorres511@gmail.com\\",\\"birthdate\\":\\"2001-11-05T00:00:00.000000Z\\",\\"email_verified_at\\":null,\\"termsAndConditions\\":true,\\"image\\":null,\\"created_at\\":\\"2025-05-23T15:09:10.000000Z\\",\\"updated_at\\":\\"2025-05-23T15:09:10.000000Z\\"}"	"{\\"id\\":3,\\"name\\":\\"Mois\\\\u00e9s\\",\\"surname\\":\\"Santana Dominguez\\",\\"email\\":\\"mjsdaw@gmail.com\\",\\"birthdate\\":\\"2001-11-05T00:00:00.000000Z\\",\\"email_verified_at\\":null,\\"termsAndConditions\\":true,\\"image\\":null,\\"created_at\\":\\"2025-05-23T15:09:10.000000Z\\",\\"updated_at\\":\\"2025-05-23T15:28:16.000000Z\\"}"	2025-05-23 16:28:16	2025-05-23 16:28:16
\.


--
-- TOC entry 3480 (class 0 OID 58761)
-- Dependencies: 236
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.bookings"
COPY public.bookings (id, space_id, user_id, start_time, end_time, status, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.bookings"
\.


--
-- TOC entry 3472 (class 0 OID 58708)
-- Dependencies: 228
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.contacts"
COPY public.contacts (id, name, email, "termsAndConditions", created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.contacts"
\.


--
-- TOC entry 3464 (class 0 OID 58664)
-- Dependencies: 220
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.failed_jobs"
COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
pg_dump: dumping contents of table "public.failed_jobs"
\.


--
-- TOC entry 3459 (class 0 OID 58636)
-- Dependencies: 215
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.migrations"
COPY public.migrations (id, migration, batch) FROM stdin;
pg_dump: dumping contents of table "public.migrations"
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_reset_tokens_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2025_05_13_122401_create_spaces_table	1
6	2025_05_13_191230_create_admins_table	1
7	2025_05_14_000000_create_contacts_table	1
8	2025_05_14_112320_create_audits_table	1
9	2025_05_20_213354_create_payments_table	1
10	2025_05_22_074228_add_direccion_to_spaces_table	1
11	2025_05_22_074601_add_direccion_to_spaces_table	1
12	2025_05_22_075135_create_spaces_table	1
13	2025_05_22_101823_create_services_table	1
14	2025_05_22_103538_add_nombre_to_services_table	1
15	2025_05_23_014535_create_booking_table	1
\.


--
-- TOC entry 3462 (class 0 OID 58656)
-- Dependencies: 218
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.password_reset_tokens"
COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
pg_dump: dumping contents of table "public.password_reset_tokens"
\.


--
-- TOC entry 3476 (class 0 OID 58731)
-- Dependencies: 232
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.payments"
COPY public.payments (id, user_id, user_reservation_id, space_reservation_id, reservation_period, amount, status, payment_method, payment_date, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.payments"
\.


--
-- TOC entry 3466 (class 0 OID 58676)
-- Dependencies: 222
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.personal_access_tokens"
COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.personal_access_tokens"
2	App\\Models\\User	1	auth_token	6f1b8773b9c577a96e2069b2ae3dcc947f3a815f007023933b6d3025c585bf5d	["*"]	2025-05-23 15:43:25	\N	2025-05-23 15:43:24	2025-05-23 15:43:25
4	App\\Models\\User	2	auth_token	ef35d3b5d5a18550df04bff122081edca6a09ad3b95755697e08f549a8b87d7b	["*"]	\N	\N	2025-05-23 16:04:29	2025-05-23 16:04:29
5	App\\Models\\User	3	auth_token	5b766b43a490edeb6188aaa63bb6a62dc1e18e8682a62afd33916256f1b5f2ee	["*"]	\N	\N	2025-05-23 16:09:10	2025-05-23 16:09:10
6	App\\Models\\Admin	1	admin_token	831eb0b9ccdaf1d631aade7745d282688ee15aea7220f1bf5980c963b2e29d62	["admin"]	2025-05-23 16:31:03	\N	2025-05-23 16:20:01	2025-05-23 16:31:03
\.


--
-- TOC entry 3478 (class 0 OID 58750)
-- Dependencies: 234
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.services"
COPY public.services (id, image_url, created_at, updated_at, name) FROM stdin;
pg_dump: dumping contents of table "public.services"
\.


--
-- TOC entry 3468 (class 0 OID 58688)
-- Dependencies: 224
-- Data for Name: spaces; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.spaces"
COPY public.spaces (id, places, price, schedule, images, description, subtitle, address, services, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.spaces"
\.


--
-- TOC entry 3461 (class 0 OID 58643)
-- Dependencies: 217
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.users"
COPY public.users (id, name, surname, dni, email, birthdate, email_verified_at, password, "termsAndConditions", image, remember_token, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.users"
3	Moisés	Santana Dominguez	eyJpdiI6IldKWmRQZEdEZFp1c2MzTDJrN1pFbmc9PSIsInZhbHVlIjoiOGE0bWh1ckJ1L0N4ZXlmZ0VOL3R6UT09IiwibWFjIjoiNTgyZjAxMjI1ZTI2ZGVhMDc0Njk4YmYwMjUxYjQwMDcyZDdlNGRiMGEyYjQzMzQ1MDQ1OThlNTNjZjM2OGI1NCIsInRhZyI6IiJ9	mjsdaw@gmail.com	2001-11-05	\N	$2y$12$silWC6ElF3HgeTTGLRLyUeWM9uXb7QEmvJMsybLaDxWybPyw//4xy	t	\N	\N	2025-05-23 16:09:10	2025-05-23 16:28:16
\.


pg_dump: executing SEQUENCE SET admins_id_seq
--
-- TOC entry 3497 (class 0 OID 0)
-- Dependencies: 225
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.admins_id_seq', 1, true);


pg_dump: executing SEQUENCE SET audits_id_seq
--
-- TOC entry 3498 (class 0 OID 0)
-- Dependencies: 229
-- Name: audits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.audits_id_seq', 3, true);


pg_dump: executing SEQUENCE SET bookings_id_seq
--
-- TOC entry 3499 (class 0 OID 0)
-- Dependencies: 235
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.bookings_id_seq', 1, false);


pg_dump: executing SEQUENCE SET contacts_id_seq
--
-- TOC entry 3500 (class 0 OID 0)
-- Dependencies: 227
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.contacts_id_seq', 1, false);


pg_dump: executing SEQUENCE SET failed_jobs_id_seq
--
-- TOC entry 3501 (class 0 OID 0)
-- Dependencies: 219
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


pg_dump: executing SEQUENCE SET migrations_id_seq
--
-- TOC entry 3502 (class 0 OID 0)
-- Dependencies: 214
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.migrations_id_seq', 15, true);


pg_dump: executing SEQUENCE SET payments_id_seq
--
-- TOC entry 3503 (class 0 OID 0)
-- Dependencies: 231
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


pg_dump: executing SEQUENCE SET personal_access_tokens_id_seq
--
-- TOC entry 3504 (class 0 OID 0)
-- Dependencies: 221
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 6, true);


pg_dump: executing SEQUENCE SET services_id_seq
--
-- TOC entry 3505 (class 0 OID 0)
-- Dependencies: 233
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.services_id_seq', 1, false);


pg_dump: executing SEQUENCE SET spaces_id_seq
--
-- TOC entry 3506 (class 0 OID 0)
-- Dependencies: 223
-- Name: spaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.spaces_id_seq', 1, false);


pg_dump: executing SEQUENCE SET users_id_seq
--
-- TOC entry 3507 (class 0 OID 0)
-- Dependencies: 216
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


pg_dump: creating CONSTRAINT "public.admins admins_email_unique"
--
-- TOC entry 3292 (class 2606 OID 58706)
-- Name: admins admins_email_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_unique UNIQUE (email);


pg_dump: creating CONSTRAINT "public.admins admins_pkey"
--
-- TOC entry 3294 (class 2606 OID 58704)
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.audits audits_pkey"
--
-- TOC entry 3298 (class 2606 OID 58724)
-- Name: audits audits_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.audits
    ADD CONSTRAINT audits_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.bookings bookings_pkey"
--
-- TOC entry 3309 (class 2606 OID 58768)
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.contacts contacts_pkey"
--
-- TOC entry 3296 (class 2606 OID 58715)
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.failed_jobs failed_jobs_pkey"
--
-- TOC entry 3281 (class 2606 OID 58672)
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.failed_jobs failed_jobs_uuid_unique"
--
-- TOC entry 3283 (class 2606 OID 58674)
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


pg_dump: creating CONSTRAINT "public.migrations migrations_pkey"
--
-- TOC entry 3271 (class 2606 OID 58641)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.password_reset_tokens password_reset_tokens_pkey"
--
-- TOC entry 3279 (class 2606 OID 58662)
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


pg_dump: creating CONSTRAINT "public.payments payments_pkey"
--
-- TOC entry 3300 (class 2606 OID 58740)
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.personal_access_tokens personal_access_tokens_pkey"
--
-- TOC entry 3285 (class 2606 OID 58683)
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.personal_access_tokens personal_access_tokens_token_unique"
--
-- TOC entry 3287 (class 2606 OID 58686)
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


pg_dump: creating CONSTRAINT "public.services services_name_unique"
--
-- TOC entry 3305 (class 2606 OID 58759)
-- Name: services services_name_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_name_unique UNIQUE (name);


pg_dump: creating CONSTRAINT "public.services services_pkey"
--
-- TOC entry 3307 (class 2606 OID 58755)
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.spaces spaces_pkey"
--
-- TOC entry 3290 (class 2606 OID 58695)
-- Name: spaces spaces_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.spaces
    ADD CONSTRAINT spaces_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.users users_dni_unique"
--
-- TOC entry 3273 (class 2606 OID 58653)
-- Name: users users_dni_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_dni_unique UNIQUE (dni);


pg_dump: creating CONSTRAINT "public.users users_email_unique"
--
-- TOC entry 3275 (class 2606 OID 58655)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


pg_dump: creating CONSTRAINT "public.users users_pkey"
--
-- TOC entry 3277 (class 2606 OID 58651)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


pg_dump: creating INDEX "public.bookings_space_id_start_time_end_time_index"
--
-- TOC entry 3310 (class 1259 OID 58779)
-- Name: bookings_space_id_start_time_end_time_index; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX bookings_space_id_start_time_end_time_index ON public.bookings USING btree (space_id, start_time, end_time);


pg_dump: creating INDEX "public.bookings_user_id_start_time_index"
--
-- TOC entry 3311 (class 1259 OID 58780)
-- Name: bookings_user_id_start_time_index; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX bookings_user_id_start_time_index ON public.bookings USING btree (user_id, start_time);


pg_dump: creating INDEX "public.payments_status_index"
--
-- TOC entry 3301 (class 1259 OID 58748)
-- Name: payments_status_index; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX payments_status_index ON public.payments USING btree (status);


pg_dump: creating INDEX "public.payments_user_id_index"
--
-- TOC entry 3302 (class 1259 OID 58746)
-- Name: payments_user_id_index; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX payments_user_id_index ON public.payments USING btree (user_id);


pg_dump: creating INDEX "public.payments_user_reservation_id_space_reservation_id_reservation_p"
--
-- TOC entry 3303 (class 1259 OID 58747)
-- Name: payments_user_reservation_id_space_reservation_id_reservation_p; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX payments_user_reservation_id_space_reservation_id_reservation_p ON public.payments USING btree (user_reservation_id, space_reservation_id, reservation_period);


pg_dump: creating INDEX "public.personal_access_tokens_tokenable_type_tokenable_id_index"
--
-- TOC entry 3288 (class 1259 OID 58684)
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


pg_dump: creating FK CONSTRAINT "public.audits audits_admin_id_foreign"
--
-- TOC entry 3312 (class 2606 OID 58725)
-- Name: audits audits_admin_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.audits
    ADD CONSTRAINT audits_admin_id_foreign FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


pg_dump: creating FK CONSTRAINT "public.bookings bookings_space_id_foreign"
--
-- TOC entry 3314 (class 2606 OID 58769)
-- Name: bookings bookings_space_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_space_id_foreign FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


pg_dump: creating FK CONSTRAINT "public.bookings bookings_user_id_foreign"
--
-- TOC entry 3315 (class 2606 OID 58774)
-- Name: bookings bookings_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


pg_dump: creating FK CONSTRAINT "public.payments payments_user_id_foreign"
--
-- TOC entry 3313 (class 2606 OID 58741)
-- Name: payments payments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-05-23 15:31:03 UTC

--
-- PostgreSQL database dump complete
--

