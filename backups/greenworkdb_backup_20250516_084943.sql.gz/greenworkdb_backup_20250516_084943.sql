--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.admins (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.admins OWNER TO "greenworkAdmin";

--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.admins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admins_id_seq OWNER TO "greenworkAdmin";

--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: audits; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.audits (
    id bigint NOT NULL,
    admin_id bigint NOT NULL,
    action character varying(255) NOT NULL,
    table_name character varying(255) NOT NULL,
    record_id bigint,
    old_values text,
    new_values text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.audits OWNER TO "greenworkAdmin";

--
-- Name: audits_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audits_id_seq OWNER TO "greenworkAdmin";

--
-- Name: audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.audits_id_seq OWNED BY public.audits.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    "termsAndConditions" boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.contacts OWNER TO "greenworkAdmin";

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contacts_id_seq OWNER TO "greenworkAdmin";

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO "greenworkAdmin";

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO "greenworkAdmin";

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO "greenworkAdmin";

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO "greenworkAdmin";

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO "greenworkAdmin";

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO "greenworkAdmin";

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_access_tokens_id_seq OWNER TO "greenworkAdmin";

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: reservations; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.reservations (
    user_id bigint NOT NULL,
    space_id bigint NOT NULL,
    reservation_period character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.reservations OWNER TO "greenworkAdmin";

--
-- Name: spaces; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.spaces (
    id bigint NOT NULL,
    places integer NOT NULL,
    price double precision NOT NULL,
    schedule character varying(255) NOT NULL,
    images character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    subtitle character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.spaces OWNER TO "greenworkAdmin";

--
-- Name: spaces_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.spaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.spaces_id_seq OWNER TO "greenworkAdmin";

--
-- Name: spaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.spaces_id_seq OWNED BY public.spaces.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    surname character varying(255) NOT NULL,
    dni character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    birthdate date NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    "termsAndConditions" boolean DEFAULT false NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO "greenworkAdmin";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO "greenworkAdmin";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: audits id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.audits ALTER COLUMN id SET DEFAULT nextval('public.audits_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: spaces id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.spaces ALTER COLUMN id SET DEFAULT nextval('public.spaces_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.admins (id, name, email, password, email_verified_at, remember_token, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.audits (id, admin_id, action, table_name, record_id, old_values, new_values, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.contacts (id, email, "termsAndConditions", created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_reset_tokens_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2025_05_13_122401_create_spaces_table	1
6	2025_05_13_123000_create_reservations_table	1
7	2025_05_13_191230_create_admins_table	1
8	2025_05_14_000000_create_contacts_table	1
9	2025_05_14_112320_create_audits_table	1
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
1	App\\Models\\User	1	auth_token	14cdf7a1608dfd4f3d1e4e380fac4de875ebf4ab1e233fc98304cc14386a2cb5	["*"]	\N	\N	2025-05-15 19:56:05	2025-05-15 19:56:05
2	App\\Models\\User	2	auth_token	f06853ff86cbef0c8683b7622aebd07ff7874986003eeb1b2ef19ebee81730cf	["*"]	\N	\N	2025-05-15 20:19:39	2025-05-15 20:19:39
35	App\\Models\\User	35	auth_token	1a3e19a8c0f6a14369d9c9a940a7e14406905f58b9ddb33164486e216610fb61	["*"]	\N	\N	2025-05-16 07:27:33	2025-05-16 07:27:33
36	App\\Models\\User	36	auth_token	f1befe147148c26402512db0070f4475a66db9afde32adbd5f51d1a18d7ad4c6	["*"]	\N	\N	2025-05-16 07:36:00	2025-05-16 07:36:00
37	App\\Models\\User	37	auth_token	256a7df419c5f3bcf8bb36d2a3ac3eaeb11c17a6c1d166de95268bec57bab94c	["*"]	\N	\N	2025-05-16 07:44:32	2025-05-16 07:44:32
38	App\\Models\\User	38	auth_token	37cf8824623ffb7b82b2445e0e694c16199a527d050b2ca246c506e7bcb6a203	["*"]	\N	\N	2025-05-16 07:47:44	2025-05-16 07:47:44
39	App\\Models\\User	39	auth_token	c9271591138ebe42d26d2f8528f4aa2b2c3ae5ba79af3563a566c527b5eab2bd	["*"]	\N	\N	2025-05-16 07:51:49	2025-05-16 07:51:49
40	App\\Models\\User	40	auth_token	2a3d0f7c65d5e6fc682b856a3efdf76325e7c09da2e18356ea4e71c2ed3bbb34	["*"]	\N	\N	2025-05-16 07:54:26	2025-05-16 07:54:26
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.reservations (user_id, space_id, reservation_period, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: spaces; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.spaces (id, places, price, schedule, images, description, subtitle, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

COPY public.users (id, name, surname, dni, email, birthdate, email_verified_at, password, "termsAndConditions", remember_token, created_at, updated_at) FROM stdin;
1	Moises	Santana	eyJpdiI6Ilg0NFk3dnNnazhCZm8vNTZGci8zSWc9PSIsInZhbHVlIjoiampnNU15ME4wb3A3K0pNcTBKbE1tdz09IiwibWFjIjoiM2FmOTRkYTM4MDg4MGQwNjQ3ZDY0MzBiMGE3YWI0NTI3OWU3MTBhOTRmM2VhNTg1NzQ2NDAxNjZhZDc5MjU5ZSIsInRhZyI6IiJ9	admin@greenwork.com	2002-08-19	\N	$2y$12$LsfK0Vw6/Ilwo/mANaqhrepbrKIPJEayZilKajnX2x7zHRgeYj6Py	t	\N	2025-05-15 19:56:05	2025-05-15 19:56:05
2	asdasd	Santana	eyJpdiI6ImhBZG1wQUFoZFFDK0Y3bjdWWUNySVE9PSIsInZhbHVlIjoidXdtOWd5dm13UHhWeDJvQVF6MHJoUT09IiwibWFjIjoiZmJjOTBjYTQ2NjE3OWMzMWVkYjE1MWE0ZTVjMGJkYmQxYmU5M2YzM2VhNjZhNmQxNTFiMTk0ZjFhZDVjMWM1OCIsInRhZyI6IiJ9	prueba@gmail.com	2002-08-19	\N	$2y$12$7V.Q/lfI4wupx3IAkTgmTOYUhnSnR4xl/NreGWLGLw8/WYk3fVTEC	t	\N	2025-05-15 20:19:39	2025-05-15 20:19:39
35	test	test	eyJpdiI6Iko0SXRsZG14cklJN3dNYjFQOVk4T3c9PSIsInZhbHVlIjoiWTRLaVR2Z2VUbUxMUDN3OHRURmsydz09IiwibWFjIjoiMGYxYjBkYjA4OGZlNjI0MzczYTM4MGE3ZWNhZTU0YWEzZDJhYjdjODBkMGJhY2Q0NTdiZWRjNjA4ZjNhYjhmOCIsInRhZyI6IiJ9	test@gmail.com	1111-11-11	\N	$2y$12$fPX7rJEjAd5Di1Wxid8XYu/jyts6nUv1MCz1xSEQ4e8zQVYcpNvz.	t	\N	2025-05-16 07:27:33	2025-05-16 07:27:33
36	test	asdasd	eyJpdiI6IkJaclp2RU9qZlZrcEd1WGxsUGxpT1E9PSIsInZhbHVlIjoiazFWc29sTFFHcklOM2ozN3VVeEIwUT09IiwibWFjIjoiNDViYTM0YzE4ZjVlNjljZjAzYTI5N2Y1MzkzNzBhNzliZDAxNDAwMDUzZTc5NmMxNjM0MzJjNjVlYWIzZjg3NyIsInRhZyI6IiJ9	12344321@gmail.com	1234-03-12	\N	$2y$12$fAcmhdzUiJltAfLf1EcJ4ueOWO3BML9yod.T44HFFrVuLEpdJkFD.	t	\N	2025-05-16 07:36:00	2025-05-16 07:36:00
37	test2	asdasd	eyJpdiI6IjlLb0hrYVI1OW1KRkZnaTd6TWJZMmc9PSIsInZhbHVlIjoiaTh0bkxvbUhUOFcrdjFFZW1CWVNWUT09IiwibWFjIjoiMjdjYWZmNjRlMGI2YWQ5ZDlmZDE5ZDJiNTE2MDVlOGZmMzZmMjQ3ZTA3YWU5MTM1MTFlYTFlMzBlNjlkNDQwZiIsInRhZyI6IiJ9	pruebadesdeusuario@gmail.com	1111-11-11	\N	$2y$12$0jKglVTcS6YcV8UIyteFTee77ISrGTipUKXWmIKQj6EdlRl03/LFK	t	\N	2025-05-16 07:44:32	2025-05-16 07:44:32
38	asdasd	asdasd	eyJpdiI6ImZQMTVzOHdwUFkvdEJXVGlRQ2lTaVE9PSIsInZhbHVlIjoiSWJjVXloOTN4UlQ1QVFudVJmZGlFQT09IiwibWFjIjoiODM3ZmZiYmJkNzIxYzEyOTIyMWY2NGE2NWNmYTUxYTU3NGUzMGYyMWI1MmMxZGYxN2U0ZmZlNDM3ZTVkMmZkNiIsInRhZyI6IiJ9	1234@gmail.com	1111-11-11	\N	$2y$12$aRj.MwNq0K/AsH6dNAEwnOfGZYO/IvGvIILywbCaLvo.AV3XwSqAG	t	\N	2025-05-16 07:47:44	2025-05-16 07:47:44
39	asdasdasd	asdasdasdads	eyJpdiI6IlFzN2hQNUFsQ1hCWmVXNUhQcEJ1UkE9PSIsInZhbHVlIjoiRFI1UnJMZTVzM3FOem1pTFhvMGoyZz09IiwibWFjIjoiZmI3ZGQyNjllZDFkODAzMmQzMmE2NjgwYjEzYzU0NzM0Njg3MWY3NzUwMGE0OTUwNzllNTA5NDIzMjA2OGE2YyIsInRhZyI6IiJ9	asdasdasd@gmail.com	1111-11-11	\N	$2y$12$OOmf3BjFqBI30Ktx2J0ZluqjDQ.H933u3u88rW9jo/ZrSJlKb7ogK	t	\N	2025-05-16 07:51:49	2025-05-16 07:51:49
40	asdasd	asdasd	eyJpdiI6InhPRHhudE13U2ZRdDN5WFBCR2orSHc9PSIsInZhbHVlIjoiampYdTBLcThiWUVkU1RmN3pKdkFtZz09IiwibWFjIjoiYTU4NzZmZWQ0ZDk1NTQ3NTBmYmVhYjdkMTMxZjhlNzk4MTUyNjQ0MGM2MmNhYzIyNzcyZDNjOWZjZWYxNjE5YyIsInRhZyI6IiJ9	asdasd@gmail.com	1111-11-11	\N	$2y$12$n2q3ixlHAwLHK..8B7OgRe/CFsurTd4GOQ5iNXh6FcvEzrnqnrnni	t	\N	2025-05-16 07:54:26	2025-05-16 07:54:26
\.


--
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.admins_id_seq', 1, false);


--
-- Name: audits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.audits_id_seq', 1, false);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.contacts_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.migrations_id_seq', 9, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 40, true);


--
-- Name: spaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.spaces_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.users_id_seq', 40, true);


--
-- Name: admins admins_email_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_unique UNIQUE (email);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: audits audits_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.audits
    ADD CONSTRAINT audits_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (user_id, space_id, reservation_period);


--
-- Name: spaces spaces_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.spaces
    ADD CONSTRAINT spaces_pkey PRIMARY KEY (id);


--
-- Name: users users_dni_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_dni_unique UNIQUE (dni);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: audits audits_admin_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.audits
    ADD CONSTRAINT audits_admin_id_foreign FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: reservations reservations_space_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_space_id_foreign FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


--
-- Name: reservations reservations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

