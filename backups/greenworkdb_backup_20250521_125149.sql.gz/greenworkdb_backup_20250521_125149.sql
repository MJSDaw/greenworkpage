pg_dump: last built-in OID is 16383
pg_dump: reading extensions
pg_dump: identifying extension members
pg_dump: reading schemas
pg_dump: reading user-defined tables
pg_dump: reading user-defined functions
pg_dump: reading user-defined types
pg_dump: reading procedural languages
pg_dump: reading user-defined aggregate functions
pg_dump: reading user-defined operators
pg_dump: reading user-defined access methods
pg_dump: reading user-defined operator classes
pg_dump: reading user-defined operator families
pg_dump: reading user-defined text search parsers
pg_dump: reading user-defined text search templates
pg_dump: reading user-defined text search dictionaries
pg_dump: reading user-defined text search configurations
pg_dump: reading user-defined foreign-data wrappers
pg_dump: reading user-defined foreign servers
pg_dump: reading default privileges
pg_dump: reading user-defined collations
pg_dump: reading user-defined conversions
pg_dump: reading type casts
pg_dump: reading transforms
pg_dump: reading table inheritance information
pg_dump: reading event triggers
pg_dump: finding extension tables
pg_dump: finding inheritance relationships
pg_dump: reading column info for interesting tables
pg_dump: finding table default expressions
pg_dump: finding table check constraints
pg_dump: flagging inherited columns in subtables
pg_dump: reading partitioning data
pg_dump: reading indexes
pg_dump: flagging indexes in partitioned tables
pg_dump: reading extended statistics
pg_dump: reading constraints
pg_dump: reading triggers
pg_dump: reading rewrite rules
pg_dump: reading policies
pg_dump: reading row-level security policies
pg_dump: reading publications
pg_dump: reading publication membership of tables
pg_dump: reading publication membership of schemas
pg_dump: reading subscriptions
pg_dump: reading large objects
pg_dump: reading dependency data
pg_dump: saving encoding = UTF8
pg_dump: saving standard_conforming_strings = on
pg_dump: saving search_path = 
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-0+deb12u1)

-- Started on 2025-05-21 12:51:49 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

pg_dump: creating TABLE "public.admins"
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 227 (class 1259 OID 41741)
-- Name: admins; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.admins (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    image character varying(255),
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.admins OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.admins_id_seq"
--
-- TOC entry 226 (class 1259 OID 41740)
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.admins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admins_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.admins_id_seq"
--
-- TOC entry 3468 (class 0 OID 0)
-- Dependencies: 226
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


pg_dump: creating TABLE "public.audits"
--
-- TOC entry 231 (class 1259 OID 41761)
-- Name: audits; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.audits (
    id bigint NOT NULL,
    admin_id bigint NOT NULL,
    action character varying(255) NOT NULL,
    table_name character varying(255) NOT NULL,
    record_id bigint,
    old_values text,
    new_values text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.audits OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.audits_id_seq"
--
-- TOC entry 230 (class 1259 OID 41760)
-- Name: audits_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audits_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.audits_id_seq"
--
-- TOC entry 3469 (class 0 OID 0)
-- Dependencies: 230
-- Name: audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.audits_id_seq OWNED BY public.audits.id;


pg_dump: creating TABLE "public.contacts"
--
-- TOC entry 229 (class 1259 OID 41752)
-- Name: contacts; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.contacts (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    "termsAndConditions" boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.contacts OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.contacts_id_seq"
--
-- TOC entry 228 (class 1259 OID 41751)
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.contacts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.contacts_id_seq"
--
-- TOC entry 3470 (class 0 OID 0)
-- Dependencies: 228
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


pg_dump: creating TABLE "public.failed_jobs"
--
-- TOC entry 220 (class 1259 OID 41692)
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.failed_jobs_id_seq"
--
-- TOC entry 219 (class 1259 OID 41691)
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.failed_jobs_id_seq"
--
-- TOC entry 3471 (class 0 OID 0)
-- Dependencies: 219
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


pg_dump: creating TABLE "public.migrations"
--
-- TOC entry 215 (class 1259 OID 41664)
-- Name: migrations; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.migrations_id_seq"
--
-- TOC entry 214 (class 1259 OID 41663)
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.migrations_id_seq"
--
-- TOC entry 3472 (class 0 OID 0)
-- Dependencies: 214
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


pg_dump: creating TABLE "public.password_reset_tokens"
--
-- TOC entry 218 (class 1259 OID 41684)
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO "greenworkAdmin";

pg_dump: creating TABLE "public.payments"
--
-- TOC entry 233 (class 1259 OID 41775)
-- Name: payments; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    user_reservation_id bigint,
    space_reservation_id bigint,
    reservation_period character varying(255),
    amount numeric(10,2) NOT NULL,
    status character varying(255) DEFAULT 'pending'::character varying NOT NULL,
    payment_method character varying(50),
    payment_date timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT payments_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'completed'::character varying])::text[])))
);


ALTER TABLE public.payments OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.payments_id_seq"
--
-- TOC entry 232 (class 1259 OID 41774)
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.payments_id_seq"
--
-- TOC entry 3473 (class 0 OID 0)
-- Dependencies: 232
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


pg_dump: creating TABLE "public.personal_access_tokens"
--
-- TOC entry 222 (class 1259 OID 41704)
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.personal_access_tokens_id_seq"
--
-- TOC entry 221 (class 1259 OID 41703)
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.personal_access_tokens_id_seq"
--
-- TOC entry 3474 (class 0 OID 0)
-- Dependencies: 221
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


pg_dump: creating TABLE "public.reservations"
--
-- TOC entry 225 (class 1259 OID 41724)
-- Name: reservations; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.reservations (
    user_id bigint NOT NULL,
    space_id bigint NOT NULL,
    reservation_period character varying(255) NOT NULL,
    status boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.reservations OWNER TO "greenworkAdmin";

pg_dump: creating TABLE "public.spaces"
--
-- TOC entry 224 (class 1259 OID 41716)
-- Name: spaces; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.spaces (
    id bigint NOT NULL,
    places integer NOT NULL,
    price double precision NOT NULL,
    schedule character varying(255) NOT NULL,
    images character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    subtitle character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.spaces OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.spaces_id_seq"
--
-- TOC entry 223 (class 1259 OID 41715)
-- Name: spaces_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.spaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.spaces_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.spaces_id_seq"
--
-- TOC entry 3475 (class 0 OID 0)
-- Dependencies: 223
-- Name: spaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.spaces_id_seq OWNED BY public.spaces.id;


pg_dump: creating TABLE "public.users"
--
-- TOC entry 217 (class 1259 OID 41671)
-- Name: users; Type: TABLE; Schema: public; Owner: greenworkAdmin
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    surname character varying(255) NOT NULL,
    dni character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    birthdate date NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    "termsAndConditions" boolean DEFAULT false NOT NULL,
    image character varying(255),
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE "public.users_id_seq"
--
-- TOC entry 216 (class 1259 OID 41670)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: greenworkAdmin
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO "greenworkAdmin";

pg_dump: creating SEQUENCE OWNED BY "public.users_id_seq"
--
-- TOC entry 3476 (class 0 OID 0)
-- Dependencies: 216
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: greenworkAdmin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


pg_dump: creating DEFAULT "public.admins id"
--
-- TOC entry 3255 (class 2604 OID 41744)
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


pg_dump: creating DEFAULT "public.audits id"
--
-- TOC entry 3257 (class 2604 OID 41764)
-- Name: audits id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.audits ALTER COLUMN id SET DEFAULT nextval('public.audits_id_seq'::regclass);


pg_dump: creating DEFAULT "public.contacts id"
--
-- TOC entry 3256 (class 2604 OID 41755)
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


pg_dump: creating DEFAULT "public.failed_jobs id"
--
-- TOC entry 3250 (class 2604 OID 41695)
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


pg_dump: creating DEFAULT "public.migrations id"
--
-- TOC entry 3247 (class 2604 OID 41667)
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


pg_dump: creating DEFAULT "public.payments id"
--
-- TOC entry 3258 (class 2604 OID 41778)
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


pg_dump: creating DEFAULT "public.personal_access_tokens id"
--
-- TOC entry 3252 (class 2604 OID 41707)
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


pg_dump: creating DEFAULT "public.spaces id"
--
-- TOC entry 3253 (class 2604 OID 41719)
-- Name: spaces id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.spaces ALTER COLUMN id SET DEFAULT nextval('public.spaces_id_seq'::regclass);


pg_dump: creating DEFAULT "public.users id"
--
-- TOC entry 3248 (class 2604 OID 41674)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3456 (class 0 OID 41741)
-- Dependencies: 227
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.admins"
COPY public.admins (id, name, email, password, email_verified_at, image, remember_token, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.admins"
1	Leo	leo@gmail.com	$2y$12$.iT1lyJrpvRdLEYje40QK.yzaY7TKoJ3zV/Q13LyEWcJ1jw8TFDWe	\N	admin-images/1lAa8RsFIE7iupjm8YMG0UixaRdLobs5UDIorOx7.webp	\N	\N	2025-05-21 09:11:51
\.


--
-- TOC entry 3460 (class 0 OID 41761)
-- Dependencies: 231
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.audits"
COPY public.audits (id, admin_id, action, table_name, record_id, old_values, new_values, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.audits"
1	1	update	users	3	"{\\"id\\":3,\\"name\\":\\"pepe\\",\\"surname\\":\\"pepe\\",\\"email\\":\\"leonardo@admin.com\\",\\"birthdate\\":\\"2001-01-01T00:00:00.000000Z\\",\\"email_verified_at\\":null,\\"termsAndConditions\\":true,\\"image\\":null,\\"created_at\\":\\"2025-05-21T09:29:04.000000Z\\",\\"updated_at\\":\\"2025-05-21T09:29:04.000000Z\\"}"	"{\\"id\\":3,\\"name\\":\\"pepe\\",\\"surname\\":\\"pepi\\",\\"email\\":\\"leonardo@admin.com\\",\\"birthdate\\":\\"2001-01-01T00:00:00.000000Z\\",\\"email_verified_at\\":null,\\"termsAndConditions\\":true,\\"image\\":null,\\"created_at\\":\\"2025-05-21T09:29:04.000000Z\\",\\"updated_at\\":\\"2025-05-21T09:31:13.000000Z\\"}"	2025-05-21 09:31:13	2025-05-21 09:31:13
2	1	update	users	3	"{\\"id\\":3,\\"name\\":\\"pepe\\",\\"surname\\":\\"pepi\\",\\"email\\":\\"leonardo@admin.com\\",\\"birthdate\\":\\"2001-01-01T00:00:00.000000Z\\",\\"email_verified_at\\":null,\\"termsAndConditions\\":true,\\"image\\":null,\\"created_at\\":\\"2025-05-21T09:29:04.000000Z\\",\\"updated_at\\":\\"2025-05-21T09:31:13.000000Z\\"}"	"{\\"id\\":3,\\"name\\":\\"pepe\\",\\"surname\\":\\"pepito\\",\\"email\\":\\"leonardo@admin.com\\",\\"birthdate\\":\\"2001-01-01T00:00:00.000000Z\\",\\"email_verified_at\\":null,\\"termsAndConditions\\":true,\\"image\\":null,\\"created_at\\":\\"2025-05-21T09:29:04.000000Z\\",\\"updated_at\\":\\"2025-05-21T10:54:25.000000Z\\"}"	2025-05-21 10:54:25	2025-05-21 10:54:25
3	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_114057.sql.gz\\"}"	2025-05-21 11:40:57	2025-05-21 11:40:57
4	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_114207.sql.gz\\"}"	2025-05-21 11:42:08	2025-05-21 11:42:08
5	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_122505.sql.gz\\"}"	2025-05-21 12:25:05	2025-05-21 12:25:05
6	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_122529.sql.gz\\"}"	2025-05-21 12:25:29	2025-05-21 12:25:29
7	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_122640.sql.gz\\"}"	2025-05-21 12:26:40	2025-05-21 12:26:40
8	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_122757.sql.gz\\"}"	2025-05-21 12:27:57	2025-05-21 12:27:57
9	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_123818.sql.gz\\"}"	2025-05-21 12:38:18	2025-05-21 12:38:18
10	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_123823.sql.gz\\"}"	2025-05-21 12:38:23	2025-05-21 12:38:23
11	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_123908.sql.gz\\"}"	2025-05-21 12:39:08	2025-05-21 12:39:08
12	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_124814.sql.gz\\"}"	2025-05-21 12:48:15	2025-05-21 12:48:15
13	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_124930.sql.gz\\"}"	2025-05-21 12:49:30	2025-05-21 12:49:30
14	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_125003.sql.gz\\"}"	2025-05-21 12:50:03	2025-05-21 12:50:03
15	1	backup	database	\N	\N	"{\\"backup_file\\":\\"\\\\\\/var\\\\\\/www\\\\\\/html\\\\\\/backups\\\\\\/greenworkdb_backup_20250521_125146.sql.gz\\"}"	2025-05-21 12:51:46	2025-05-21 12:51:46
\.


--
-- TOC entry 3458 (class 0 OID 41752)
-- Dependencies: 229
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.contacts"
COPY public.contacts (id, name, email, "termsAndConditions", created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.contacts"
\.


--
-- TOC entry 3449 (class 0 OID 41692)
-- Dependencies: 220
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.failed_jobs"
COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
pg_dump: dumping contents of table "public.failed_jobs"
\.


--
-- TOC entry 3444 (class 0 OID 41664)
-- Dependencies: 215
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.migrations"
COPY public.migrations (id, migration, batch) FROM stdin;
pg_dump: dumping contents of table "public.migrations"
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_reset_tokens_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2025_05_13_122401_create_spaces_table	1
6	2025_05_13_123000_create_reservations_table	1
7	2025_05_13_191230_create_admins_table	1
8	2025_05_14_000000_create_contacts_table	1
9	2025_05_14_112320_create_audits_table	1
10	2025_05_20_213354_create_payments_table	1
\.


--
-- TOC entry 3447 (class 0 OID 41684)
-- Dependencies: 218
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.password_reset_tokens"
COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
pg_dump: dumping contents of table "public.password_reset_tokens"
\.


--
-- TOC entry 3462 (class 0 OID 41775)
-- Dependencies: 233
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.payments"
COPY public.payments (id, user_id, user_reservation_id, space_reservation_id, reservation_period, amount, status, payment_method, payment_date, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.payments"
\.


--
-- TOC entry 3451 (class 0 OID 41704)
-- Dependencies: 222
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.personal_access_tokens"
COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.personal_access_tokens"
2	App\\Models\\User	1	auth_token	98f1f319963f0dea0e7e620e67239f7bdf9d1766313734fedf7854e45ba552fa	["*"]	2025-05-21 08:37:41	\N	2025-05-21 08:37:41	2025-05-21 08:37:41
5	App\\Models\\User	2	auth_token	06aa3abde89051beea0024aff60d972a3b012d2d47762944d3cb362a9bc8d4de	["*"]	\N	\N	2025-05-21 09:24:25	2025-05-21 09:24:25
9	App\\Models\\Admin	1	admin_token	7c4b45e9dcddbd0bab344969f1c37733db92f34357e3972367e0d98e96a93f58	["admin"]	2025-05-21 12:51:49	\N	2025-05-21 12:25:01	2025-05-21 12:51:49
6	App\\Models\\User	3	auth_token	7d06b3607c4ed46f3c8e3ae259d29ac4cc8648aabed5f0980a905ade2ce0ffa8	["*"]	\N	\N	2025-05-21 09:29:04	2025-05-21 09:29:04
\.


--
-- TOC entry 3454 (class 0 OID 41724)
-- Dependencies: 225
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.reservations"
COPY public.reservations (user_id, space_id, reservation_period, status, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.reservations"
\.


--
-- TOC entry 3453 (class 0 OID 41716)
-- Dependencies: 224
-- Data for Name: spaces; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.spaces"
COPY public.spaces (id, places, price, schedule, images, description, subtitle, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.spaces"
\.


--
-- TOC entry 3446 (class 0 OID 41671)
-- Dependencies: 217
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: greenworkAdmin
--

pg_dump: processing data for table "public.users"
COPY public.users (id, name, surname, dni, email, birthdate, email_verified_at, password, "termsAndConditions", image, remember_token, created_at, updated_at) FROM stdin;
pg_dump: dumping contents of table "public.users"
1	Aileen	Padrón Torres	eyJpdiI6ImJtQWFpMTNwTmo0emdnbUtQMTdMakE9PSIsInZhbHVlIjoiR1RFYlYvOW5qOENOUlpvenVMNDQvdz09IiwibWFjIjoiMmQ3ODliMzRlYjI4N2IwZGM4ZjRlNDBhMmYxOTIxYjA0ZmFjNzliMDcwNWU0ODZiYjk3ZTY3YTFhODBjZTAzMiIsInRhZyI6IiJ9	aileenpadrontorres511@gmail.com	2001-11-05	\N	$2y$12$.iT1lyJrpvRdLEYje40QK.yzaY7TKoJ3zV/Q13LyEWcJ1jw8TFDWe	t	\N	\N	2025-05-21 08:37:29	2025-05-21 08:37:29
2	Moises	Padrón Torres	eyJpdiI6Inp1S3hUT3JFRi8ra0pucWNQa2tOQ0E9PSIsInZhbHVlIjoiNjNKdytGSlFpN05CejFJaDIrclU5QT09IiwibWFjIjoiNTIxNWJlOGE3MTdkYzRiNWY3Y2JmMDJkZmYxMjJlZTE2ZmVjODM0ZmY3NmIwYzNmMDI0YTEzZjAzMjQxYjM1NyIsInRhZyI6IiJ9	admin@greenwork.com	2001-05-01	\N	$2y$12$e5MnO.wlt7QcFQ2HeXALm.jCiCgfKK6jSr5nY9IVbFAxZgdQQ26uK	t	\N	\N	2025-05-21 09:24:25	2025-05-21 09:24:25
3	pepe	pepito	eyJpdiI6Ik9ONGlyYXpUdkI4WlBwUlU1S2xocUE9PSIsInZhbHVlIjoiK0FGOEszeWV5eVBLUWR0NzRoVUVFQT09IiwibWFjIjoiNjlkNWZkNjI4M2I5NGMwZWJlNjBkNWYwYzZlNWY4NjgzMTliMDA4NjI2NGQyYWZiNjlhMDg3OGZhMmE1ZTI0ZSIsInRhZyI6IiJ9	leonardo@admin.com	2001-01-01	\N	$2y$12$BblLnZJ4o15JFOTzn.hk1u42mk03JyQoXKxWJXvQ3n1mDzE3Cl7qm	t	\N	\N	2025-05-21 09:29:04	2025-05-21 10:54:25
\.


pg_dump: executing SEQUENCE SET admins_id_seq
--
-- TOC entry 3477 (class 0 OID 0)
-- Dependencies: 226
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.admins_id_seq', 1, true);


pg_dump: executing SEQUENCE SET audits_id_seq
--
-- TOC entry 3478 (class 0 OID 0)
-- Dependencies: 230
-- Name: audits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.audits_id_seq', 15, true);


pg_dump: executing SEQUENCE SET contacts_id_seq
--
-- TOC entry 3479 (class 0 OID 0)
-- Dependencies: 228
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.contacts_id_seq', 1, false);


pg_dump: executing SEQUENCE SET failed_jobs_id_seq
--
-- TOC entry 3480 (class 0 OID 0)
-- Dependencies: 219
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


pg_dump: executing SEQUENCE SET migrations_id_seq
--
-- TOC entry 3481 (class 0 OID 0)
-- Dependencies: 214
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.migrations_id_seq', 10, true);


pg_dump: executing SEQUENCE SET payments_id_seq
--
-- TOC entry 3482 (class 0 OID 0)
-- Dependencies: 232
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


pg_dump: executing SEQUENCE SET personal_access_tokens_id_seq
--
-- TOC entry 3483 (class 0 OID 0)
-- Dependencies: 221
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 9, true);


pg_dump: executing SEQUENCE SET spaces_id_seq
--
-- TOC entry 3484 (class 0 OID 0)
-- Dependencies: 223
-- Name: spaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.spaces_id_seq', 1, false);


pg_dump: executing SEQUENCE SET users_id_seq
--
-- TOC entry 3485 (class 0 OID 0)
-- Dependencies: 216
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: greenworkAdmin
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


pg_dump: creating CONSTRAINT "public.admins admins_email_unique"
--
-- TOC entry 3285 (class 2606 OID 41750)
-- Name: admins admins_email_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_unique UNIQUE (email);


pg_dump: creating CONSTRAINT "public.admins admins_pkey"
--
-- TOC entry 3287 (class 2606 OID 41748)
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.audits audits_pkey"
--
-- TOC entry 3291 (class 2606 OID 41768)
-- Name: audits audits_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.audits
    ADD CONSTRAINT audits_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.contacts contacts_pkey"
--
-- TOC entry 3289 (class 2606 OID 41759)
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.failed_jobs failed_jobs_pkey"
--
-- TOC entry 3272 (class 2606 OID 41700)
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.failed_jobs failed_jobs_uuid_unique"
--
-- TOC entry 3274 (class 2606 OID 41702)
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


pg_dump: creating CONSTRAINT "public.migrations migrations_pkey"
--
-- TOC entry 3262 (class 2606 OID 41669)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.password_reset_tokens password_reset_tokens_pkey"
--
-- TOC entry 3270 (class 2606 OID 41690)
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


pg_dump: creating CONSTRAINT "public.payments payments_pkey"
--
-- TOC entry 3293 (class 2606 OID 41784)
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.personal_access_tokens personal_access_tokens_pkey"
--
-- TOC entry 3276 (class 2606 OID 41711)
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.personal_access_tokens personal_access_tokens_token_unique"
--
-- TOC entry 3278 (class 2606 OID 41714)
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


pg_dump: creating CONSTRAINT "public.reservations reservations_pkey"
--
-- TOC entry 3283 (class 2606 OID 41739)
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (user_id, space_id, reservation_period);


pg_dump: creating CONSTRAINT "public.spaces spaces_pkey"
--
-- TOC entry 3281 (class 2606 OID 41723)
-- Name: spaces spaces_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.spaces
    ADD CONSTRAINT spaces_pkey PRIMARY KEY (id);


pg_dump: creating CONSTRAINT "public.users users_dni_unique"
--
-- TOC entry 3264 (class 2606 OID 41681)
-- Name: users users_dni_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_dni_unique UNIQUE (dni);


pg_dump: creating CONSTRAINT "public.users users_email_unique"
--
-- TOC entry 3266 (class 2606 OID 41683)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


pg_dump: creating CONSTRAINT "public.users users_pkey"
--
-- TOC entry 3268 (class 2606 OID 41679)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


pg_dump: creating INDEX "public.payments_status_index"
--
-- TOC entry 3294 (class 1259 OID 41792)
-- Name: payments_status_index; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX payments_status_index ON public.payments USING btree (status);


pg_dump: creating INDEX "public.payments_user_id_index"
--
-- TOC entry 3295 (class 1259 OID 41790)
-- Name: payments_user_id_index; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX payments_user_id_index ON public.payments USING btree (user_id);


pg_dump: creating INDEX "public.payments_user_reservation_id_space_reservation_id_reservation_p"
--
-- TOC entry 3296 (class 1259 OID 41791)
-- Name: payments_user_reservation_id_space_reservation_id_reservation_p; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX payments_user_reservation_id_space_reservation_id_reservation_p ON public.payments USING btree (user_reservation_id, space_reservation_id, reservation_period);


pg_dump: creating INDEX "public.personal_access_tokens_tokenable_type_tokenable_id_index"
--
-- TOC entry 3279 (class 1259 OID 41712)
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: greenworkAdmin
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


pg_dump: creating FK CONSTRAINT "public.audits audits_admin_id_foreign"
--
-- TOC entry 3299 (class 2606 OID 41769)
-- Name: audits audits_admin_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.audits
    ADD CONSTRAINT audits_admin_id_foreign FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


pg_dump: creating FK CONSTRAINT "public.payments payments_user_id_foreign"
--
-- TOC entry 3300 (class 2606 OID 41785)
-- Name: payments payments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


pg_dump: creating FK CONSTRAINT "public.reservations reservations_space_id_foreign"
--
-- TOC entry 3297 (class 2606 OID 41733)
-- Name: reservations reservations_space_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_space_id_foreign FOREIGN KEY (space_id) REFERENCES public.spaces(id) ON DELETE CASCADE;


pg_dump: creating FK CONSTRAINT "public.reservations reservations_user_id_foreign"
--
-- TOC entry 3298 (class 2606 OID 41728)
-- Name: reservations reservations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: greenworkAdmin
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-05-21 12:51:49 UTC

--
-- PostgreSQL database dump complete
--

